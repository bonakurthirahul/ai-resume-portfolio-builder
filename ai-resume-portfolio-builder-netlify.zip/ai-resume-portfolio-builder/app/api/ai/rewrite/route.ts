export { POST } from '../route';
